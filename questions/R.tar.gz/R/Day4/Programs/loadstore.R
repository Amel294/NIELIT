
ls()
list.files()
save.image() 
rm(list=ls())
load(".RData")

save.image("new.Rdata")
list.files()
getwd()
load("new.Rdata")




