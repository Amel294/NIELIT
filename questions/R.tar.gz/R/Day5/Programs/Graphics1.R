plot(c(1,2,3),c(3,4,5))
plot(c(-3,3), c(-1,5), type = "n", xlab="x", ylab="y")


x<-c(1,2,3)
y<-c(1,3,8)
plot(x,y)
dev.off()
