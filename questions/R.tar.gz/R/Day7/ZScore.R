

x=30:50
mu=mean(x)
sigma=sd(x)
z=(x-mu)/sigma


