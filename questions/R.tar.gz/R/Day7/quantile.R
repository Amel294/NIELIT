data2<-c(1, 5, 7 ,5, 3, 2, 6, 8, 5, 6)
quantile(data2, 0.3) 
quantile(data2, c(0.2, 0.5, 0.8)) 

data2 <-  c(3, 5, 7, 5 ,3, 2, 6, 8, 5, 6, 9,4, 5, 7, 3, 4)
cumsum(data2)

cummax(data2)

cumprod(data2)
seq(along = data2) 
seq(data2) 

seq_along(data2) 